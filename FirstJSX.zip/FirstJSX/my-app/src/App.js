import './App.css';
import HelloDojoComponent from './components/HelloDojo.js'

function App() {
  return ( <div div className = "App" >
    <HelloDojoComponent/>
    </div>
  );
}

export default App;