import React, { Component } from "react";

class Company extends Component{

    constructor ( ) {
        this.name = faker.company.companyName();
        this.address;
        this.street = faker.address.streetAddress();
        this.city = faker.address.city();
        this.state = faker.address.state();
        this.zipCode = faker.address.zipCode();
        this.country = faker.address.country();
        
    }

    render () {
        return (
            <div>

            </div>
        )
    }

}