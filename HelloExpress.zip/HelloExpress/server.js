const express = require( "express" );
const app = express();
const port = 8000;
app.use( express.json() );
app.use( express.urlencoded( {extended: true} ) );
const faker = require( 'faker' );


// const users = [ {
//     firstName: "Reimu",
//     lastName: "Hakurei"
//   },
//   {
//     firstName: "Marisa",
//     lastName: "Kirisame"
//   },
//   {
//     firstName: "Sanae",
//     lastName: "Kochiya"
//   },
//   {
//     firstName: "Sakuya",
//     lastName: "Izayoi"
//   },
//   {
//     firstName: "Momiji",
//     lastName: "Inubashiri"
//   }
// ];
class Person  {
  constructor () {
    this._id = faker.random.number();
    this.firstName = faker.name.firstName();
    this.lastName = faker.name.lastName();
    this.phoneNumber = faker.phone.phoneNumber();
    this.email = faker.internet.email();
    this.password = faker.internet.password();
  }
}
const newPerson = new Person();

class Address {
  constructor() {
    this.street = faker.address.streetAddress();
    this.city = faker.address.city();
    this.state = faker.address.state();
    this.zipCode = faker.address.zipCode();
    this.country = faker.address.country();
  }
}
const newAddress = new Address();

class Company {
  constructor() {
    this._id = faker.random.number();
    this.name = faker.company.companyName();
    this.address = newAddress;
  }
}
const newCompany = new Company();

app.get( "/api/:type/:new", ( req, res ) => {
  if ( req.params.type === "person" && req.params.new === "company" ) {
    res.send( `User First Name: ${newPerson.firstName}; Company name: ${newCompany.name}` );
  }
  if ( req.params.type === "person" ) {
    res.json( `Person First Name: ${newPerson}; Person Last Name: ${newPerson.lastName}` );
  }
  if ( req.params.type === "company" ) {
    res.send( `Company name: ${newCompany.name}` );
  }
  // req.body = newUser;
  // console.log(req.body);
  // return res.status(201).json({newUser: newUser});
} );

// app.delete( "/api/users/:id", ( req, res ) => {
//   // we can get this `id` variable from req.params
//   const id = req.params.id;
//   // assuming this id is the index of the users array we can remove the user like so
//   users.splice( id, 1 );
//   // we always need to respond with something
//   res.json( {
//     status: "ok"
//   } );
// } );

// app.put( "/api/users/:id", ( req, res ) => {
//   // we can get this `id` variable from req.params
//   const id = req.params.id;
//   // assuming this id is the index of the users array we can replace the user like so
//   users[ id ] = req.body;
//   // we always need to respond with something
//   res.json( {
//     status: "ok"
//   } );
// } );

// app.get( "/api/users/:id", ( req, res ) => {
//   // we can get this `id` variable from req.params
//   console.log( req.params.id );
//   // assuming this id is the index of the users array we could return one user this way
//   res.json( users[ req.params.id ] );
// } );

// app.post( "/api/users", ( req, res ) => {
//   // req.body will contain the form data from Postman or from React
//   console.log( req.body );
//   // we can push it into the users array for now...
//   // later on this will be inserted into a database
//   users.push( req.body );
//   // we always need to respond with something
//   res.json( {
//     status: "ok"
//   } );
// } );

// app.get( "/api/users", ( req, res ) => {
//   res.json( users );
// } );
// // req is short for request
// // res is short for response
// app.get("/api", (req, res) => {
//   res.send("Our express api server is now sending this over to the browser");
// });

const server = app.listen(8000, () =>
  console.log(`Server is locked and loaded on port ${server.address().port}!`)
);
