import './App.css';
import React from 'react';
import { Router } from '@reach/router';
import Main from './views/Main';
import AddAuthor from './components/AddAuthor';
import EditAuthor from './components/EditAuthor';
function App() {
  return (
    <div className="App">
      <Router>
        <Main path="/" />
        <AddAuthor path="author/add" />
        <EditAuthor path="author/:id/edit"/>
      </Router>
    </div>
  );
}

export default App;
