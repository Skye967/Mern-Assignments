import React, { useState } from 'react';
import axios from 'axios';
import { Link, navigate } from '@reach/router';
import '../App.css';

export default () => {
    const [ name, setName ] = useState( "" );
    const [ errors, setErrors ] = useState( [] );
    
    const submitHandler = ( e ) => {
        e.preventDefault();
        axios.post( 'http://localhost:8000/api/author', {
            name
        } )
            .then( ( res ) => {
                console.log( res );
                navigate( "/" );
            } )
            .catch( ( err ) => {
                const errorResponse = err.response.data.errors;
                const errorArr = [];
                for ( const key of Object.keys( errorResponse ) ) {
                    errorArr.push( errorResponse[ key ].message );
                }
                setErrors( errorArr );
            } );
    };


    return (
        <div>
            <h1>Who's your favorite Author</h1>
            <Link to={"/"}>Home</Link>
            <form onSubmit={ submitHandler }>
                {
                    errors.map( ( err, i ) => <p className="error" key={ i }>{err}</p>)
                }
                <div>
                    <label>Name: </label>
                    <input type="text" name="name" value={ name }
                        onChange={ (e) => setName(e.target.value)}/>
                </div>
                <div>
                    <button><Link to={"/"}>Cancel</Link></button>
                    <input type="submit"/>
                </div>
            </form>
        </div>
    )
}