import React from 'react';
import '../App.css';
import { Link } from '@reach/router';
import axios from 'axios';
export default props => {
    const { removeFromDom } = props;

    const deleteAuthor = ( authorId ) => {
        axios.delete( 'http://localhost:8000/api/author/' + authorId )
            .then( res => {
                removeFromDom( authorId );
                window.location.reload( false );
        })
    }

    return (
        <div className="table_container">
            <table className="author_table">
                <tr>
                    <th>Name</th>
                    <th>Actions Available</th>
                </tr>
            {
                props.authors.map( (author, i)  => {
                return(
                    <tr>
                        <td>{ author.name }</td>
                        <td>
                            <button><Link to={ "/author/" + author._id + "/edit" }>Edit</Link></button>
                            <button onClick={(e) => {deleteAuthor(author._id)}}>Delete</button>
                        </td>
                    </tr>
                )
                })
                }
            </table>
        </div>
    )
}