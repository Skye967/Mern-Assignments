const mongoose = require( 'mongoose' );
mongoose.set( 'runValidators', true );

mongoose.connect( "mongodb://localhost/authordb", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useFindAndModify: false
} )

    .then( () => console.log( "Estatblished a connection to the database" ) )
    .catch( ( err ) => console.log( "something went wrong when connecting to the database", err ) );