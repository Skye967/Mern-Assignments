const mongoose = require( 'mongoose' );

const AuthorSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: [ true, "Author needs a name." ],
            minlength: [ 3, "Author name nedds to be 3 or more characters long." ]
        }
    }, { timestamps: true }
);
module.exports.Author = mongoose.model( 'Author', AuthorSchema );