import logo from './logo.svg';
import './App.css';
import React, { useState, useEffect } from 'react';
import axios from 'axios';

function App () {
  const [ pokemon, setPokemon ] = useState( [] );
  const [ pokemon2, setPokemon2 ] = useState( [] ); 
 
  useEffect( () => {
    axios.get( "https://pokeapi.co/api/v2/pokemon" )
      .then(response => {
        console.log( response.data.results );
        setPokemon2( response.data.results );
      }).catch( err => {
        console.log( err );
      })
  }, [])
  
  const displayPokemon = () => {
    console.log( pokemon.length );
    if ( pokemon.length == 0 ) {
      setPokemon(pokemon2)
    } else {
      setPokemon( [] );
    }
  }


  return (
    <div className="App">
      <p>hello</p>
      <button onClick={displayPokemon}>Fetch Pokemon</button>
      {
        pokemon.map( ( poke, idx ) => {
          return <p key={ idx }>{poke.name}</p>
        })
      }
    </div>
  );
}

export default App;