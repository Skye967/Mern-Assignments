
import './App.css';
import React, { useState } from 'react';
import PersonForm from './components/PersonForm';
import Person from './components/Person';
function App () {
  const [ state, setState ] = useState( {
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    confirmationPassword: ""
  } );

  return (
    <div className="App">
      <PersonForm input={ state } setInputs={ setState } />
      <Person data={state}/>
    </div>
  );
}

export default App;
