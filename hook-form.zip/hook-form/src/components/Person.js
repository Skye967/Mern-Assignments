import React from "react";


const Person =  props => {
    const  {firstName, lastName, email, password, confirmationPassword } = props.data;

    return (
        <div className="form">
            <p>First Name: { firstName }</p>
            <p>Last Name: { lastName }</p>
            <p>Email: { email }</p>
            <p>Password: { password }</p>
            <p>confirmationPassword: { confirmationPassword }</p>
        </div>
    );
};

export default Person;