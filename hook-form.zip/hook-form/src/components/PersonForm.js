import React from "react";

const PersonForm = props => {
    const { inputs, setInputs}  = props;


    const change = e => {
         setInputs({
             ...inputs,
             [ e.target.name ]: e.target.value
        });
    };

        return (
            <form className="form">
                <label htmlFor="firstName">First Name: </label>
                <input onChange={ change } type="text" name="firstName" />
                <label htmlFor="lastName">Last Name: </label>
                <input onChange={ change } type="text" name="lastName" />
                <label htmlFor="email">Email: </label>
                <input onChange={ change } type="text" name="email" />
                <label htmlFor="password">Password: </label>
                <input onChange={ change } type="text" name="password" />
                <label htmlFor="confirmationPassword">Confirmation Password: </label>
                <input onChange={change} type="text" name="confirmationPassword"/>
            </form>
        )
}

export default PersonForm;