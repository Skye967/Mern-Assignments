
import './App.css';
import StarWars from './components/starWars';
import React, { useState, useEffect } from 'react';
import { navigate } from "@reach/router";
import {Router} from "@reach/router";
function App () {
  const [ starList, setStarList ] = useState( [] );
  const [starDisplay, setStarDisplay] = useState( [] );
  const [starType, setStarType] = useState( "people" );
  const [ starNum, setStarNum ] = useState( [] );
  let starKeys = [];

  const numList = [];
  for ( let i = 1; i < starList.length + 1; i++ ){
    numList.push( i );
  }
  
//   const submitHandler = ( e ) => {
//     e.preventDefault();
//     console.log( starType, starNum );
//     console.log( "works" );
//     if ( starType === "people" ) {
//       fetch( "https://swapi.dev/api/people" )
//       .then(response => {
//         return response.json();
//       } ).then( response => {
//         setStarList( response.results );
//         setStarDisplay( starList[ starNum ] );
//         console.log( response.results );
//         console.log( starList[ starNum ] );
//       } )
//     }
//     if ( starType === "planet" ) {
//       fetch( "https://swapi.dev/api/planets" )
//       .then(response => {
//         return response.json();
//       } ).then( response => {
//         setStarList( response.results );
//         setStarDisplay( starList[ starNum ] );
//         console.log( response.results );
//         console.log( starList[starNum] );
//       } )
//     }
// }

  
  const submitHandler = ( e ) => {
    e.preventDefault();
    // console.log( starType, starNum );
    navigate( `/${ starType }/${ starNum }` );
    // console.log(starList)
    // console.log( "works" );
  }

  return (
    <div className="App">
      <h1>Luke Skyewalker</h1>
      <form onSubmit={submitHandler}>
        <label for="searching">Planet: </label>
        <select value = {starType}  onChange = {e => setStarType( e.target.value )} >
          <option value="people">People</option>
          <option value="planets">Planet</option>
        </select>
        <label for="numList">id: </label>
        <input value={ starNum } type="number" onChange={ e => setStarNum( e.target.value ) } />
        <input type="submit" />
      </form>
       {/* {
        Object.keys( starDisplay ).map( ( star ) => {
          return <p value={ star }>{star}: {starDisplay[star]}</p>
        })
       }  */}
      <Router>
        <StarWars path="/:type/:id/"/>
      </Router>
    </div>
  );
}

export default App;
