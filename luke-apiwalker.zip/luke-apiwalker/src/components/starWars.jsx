import React from 'react';
import { Router } from '@reach/router';
import { Link, navigate } from '@reach/router';
import  { useState, useEffect } from 'react';

const StarWars = ( {type, id} ) => {
    const [ starDisplay, setStarDisplay ] = useState( [] );
    console.log( type, id );
       useEffect(() => {
        fetch("https://swapi.dev/api/" + type + "/" + id)
            .then(res => {
                return res.json();
            } ).then( res => {
                setStarDisplay( res );
                console.log(starDisplay)
            })
            .catch(err => {
                console.log(err);
                navigate("/404");
            })
       }, [ type, id ] )
    
    return (
        <div>
            {
        Object.keys( starDisplay ).map( ( star ) => {
          return <p value={ star }>{star}: {starDisplay[star]}</p>
        })
      } 
        </div>
    )
}

export default StarWars;