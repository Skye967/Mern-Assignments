
import './App.css';
import React, { useState } from 'react';
import UserForm from './components/UserForm';
import Person from './components/Person';
function App () {
  const [ state, setState ] = useState( {
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    confirmationPassword: ""
  } );

  return (
    <div className="App">
      <UserForm inputs={ state } setInputs={ setState } />
      <Person data={state}/>
    </div>
  );
}

export default App;
