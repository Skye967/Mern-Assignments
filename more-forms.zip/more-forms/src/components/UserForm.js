import React, { useState } from  'react';
    
    
const UserForm = ( props ) => {
    const { inputs, setInputs}  = props;
 //    const [ firstName, setFirstName ] = useState( "" );
     const [firstNameError, setFirstNameError] = useState("");
//     const [ lastName, setLastName ] = useState( "" );
     const [lastNameError, setLastNameError] = useState("");
//     const [ email, setEmail ] = useState( "" );
     const [emailError, setEmailError] = useState("");
//     const [ password, setPassword ] = useState( "" );
     const [passwordError, setPasswordError] = useState("");
//     const [ confirmationPassword, setConfirmationPassword ] = useState( "" );
     const [confirmationPasswordError, setConfirmationPasswordError] = useState("");
//     const [hasBeenSubmitted, setHasBeenSubmitted] = useState(false);
    
    const createUser = ( e ) => {
        
        // e.preventDefault();
        // const newUser = { firstName, lastName, email, password, confirmationPassword };
        // console.log("Welcome", newUser);
        // setHasBeenSubmitted( true );
        // if ( firstName.length < 2 ) {
        //     setFirstNameError("First Name must be 2 characters or longer");
        // }
        // if ( lastName.length < 2 ) {
        //     setLastNameError("Last Name must be 2 characters or longer");
        // }
        // if ( email.length < 5 ) {
        //     setEmailError("Email must be 5 characters or longer");
        // }
        // if ( password.length < 8 ) {
        //     setPasswordError("Password must be 8 characters or longer");
        // }
        // if ( password !== confirmationPassword ) {
        //     setConfirmationPasswordError("Password confirmation must match password");
        // }
    };

    const change = e => {
         setInputs({
             ...inputs,
             [ e.target.name ]: e.target.value
         });
        console.log( e.target.value );

        if ( e.target.name == 'firstName' && e.target.value.length < 2 ) {
             setFirstNameError("First Name must be 2 characters or longer");
        } else {
            setFirstNameError( "" );
        }
        if ( e.target.name == 'lastName' && e.target.value.length < 2 ) {
            setLastNameError( "Last Name must be 2 characters or longer" );
        } else {
            setLastNameError( "" );
        }
        if ( e.target.name == 'email' && e.target.value.length < 5 ) {
            setEmailError( "Email must be 5 characters or longer" );
        } else {
            setEmailError( "" );
        }
        if ( e.target.name == 'password' && e.target.value.length < 8 ) {
            setPasswordError( "Password must be 8 characters or longer" );
        } else {
            setPasswordError( "" );
        }
        if ( e.target.name == 'confirmationPassword' && e.target.value != inputs.password ) {
            setConfirmationPasswordError( "Password Confirmation must be the same ass password" );
        } else {
            setConfirmationPasswordError( "" );
        }
    };
        //  if ( lastName.length < 2 ) {
        //      setLastNameError("Last Name must be 2 characters or longer");
        //  }
        //  if ( email.length < 5 ) {
        //      setEmailError("Email must be 5 characters or longer");
        //  }
        //  if ( password.length < 8 ) {
        //      setPasswordError("Password must be 8 characters or longer");
        //  }
        //  if ( password !== confirmationPassword ) {
        //      setConfirmationPasswordError("Password confirmation must match password");
        //  }
    
    
    
//     const formMessage = () => {
//         if( hasBeenSubmitted ) {
// 	    return "Thank you for submitting the form!";
// 	} else {
// 	    return "Welcome, please submit the form";
// 	}
//     };
    
    return (
        <form >
            {/* <h3>{ formMessage() }</h3> */}
            <div>
                {
                    firstNameError ?
                        <p style={ { color: 'red' } }>{ firstNameError }</p> :
                    <p>&nbsp;</p>
                }
                <label>First Name: </label> 
                <input type="text" onChange={ change } name="firstName"/>
            </div>
            {/* (e) => setFirstName(e.target.value) */}
            <div>
                {
                    lastNameError ?
                    <p style={{color:'red'}}>{ lastNameError }</p> :
                    <p> &nbsp; </p>
                }
                <label>Last Name: </label> 
                <input type="text" onChange={ change } name="lastName"/>
            </div>
            <div>
                {
                    emailError ?
                    <p style={{color:'red'}}>{ emailError }</p> :
                    <p> &nbsp; </p>
                }
                <label>Email Address: </label> 
                <input type="text" onChange={change} name="email"/>
            </div>
            <div>
                {
                    passwordError ?
                    <p style={{color:'red'}}>{ passwordError }</p> :
                    <p> &nbsp; </p>
                }
                <label>Password: </label>
                <input type="text" onChange={change} name="password"/>
            </div>
            <div>
                {
                    confirmationPasswordError ?
                    <p style={{color:'red'}}>{ confirmationPasswordError }</p> :
                    <p> &nbsp; </p>
                }
                <label>Password Confirmation: </label>
                <input type="text" onChange={change} name="confirmationPassword"/>
            </div>
        </form>
    );
};
    
export default UserForm;