import logo from './logo.svg';
import './App.css';
import ProductForm from './components/productForm';

function App() {
  return (
    <div className="App">
      <ProductForm/>
    </div>
  );
}

export default App;
