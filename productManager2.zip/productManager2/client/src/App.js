import './App.css';
import React from 'react';
import Main from './views/Main';
import Display from './views/Display';
import {Router} from '@reach/router';


function App() {
  return (
    <div className="App">
      <Router>
        <Main path="/" />
        <Display path="/:id" />
      </Router>
    </div>
  );
}

export default App;
