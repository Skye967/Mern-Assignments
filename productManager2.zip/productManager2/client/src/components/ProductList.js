import React from 'react';
import { Link } from '@reach/router';

export default props => {
    const products = props.product;
    return (
        <div>
            {
                products.map( ( product, i ) => {
                return <p key={ i } > <Link to={ '/' + product._id }>{product.title}</Link></p>
                } )
            }
             
        </div>
    )
}