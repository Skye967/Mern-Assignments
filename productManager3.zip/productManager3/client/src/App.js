import './App.css';
import React from 'react';
import Main from './views/Main';
import Display from './views/Display';
import ProductUpdate from './components/ProductUpdate';
import { Router } from '@reach/router';
import { useState, useEffect } from 'react';
import axios from 'axios';

function App () {
      const [ product, setProduct ] = useState( [] );
    const [ loaded, setLoaded ] = useState( false );

    useEffect( () => {
        axios.get( 'http://localhost:8000/api/find' )
            .then( res => {
                setProduct( res.data );
                setLoaded( true );
            } );
    }, [] );
    
    const removeFromDom = productId => {
        setProduct( product.filter( pro => pro._id != productId ) );
    };

  return (
    <div className="App">
      <Router>
        <Main path="/" />
        <Display path="/:id" removeFromDom={removeFromDom}/>
        <ProductUpdate path="product/:id/edit"/>
      </Router>
    </div>
  );
}

export default App;
