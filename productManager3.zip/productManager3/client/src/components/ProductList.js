import React from 'react';
import { Link } from '@reach/router';
import axios from 'axios';

export default props => {
    const products = props.product;
    const { removeFromDom } = props;

    const deleteProduct = ( productId ) => {
        console.log( productId );
        axios.delete( 'http://localhost:8000/api/product/' + productId )
            .then( res => {
                removeFromDom( productId );
                window.location.reload(false)
        })
    }


    return (
        <div>
            {
                products.map( ( product, i ) => {
                    return (
                        <div>
                            <Link to={ '/' + product._id }>{ product.title }</Link>
                            <button><Link to={ "/product/" + product._id + "/edit" }>Edit</Link></button>
                            <button onClick={(e) => {deleteProduct(product._id)}}>Delete</button>
                        </div>
                    )
                } )
            }
             
        </div>
    )
}