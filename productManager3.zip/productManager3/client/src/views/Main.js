import React, { useState, useEffect } from 'react';
import ProductForm from '../components/productForm';
import ProductList from '../components/ProductList';
import axios from 'axios';

export default () => {
    const [ product, setProduct ] = useState( [] );
    const [ loaded, setLoaded ] = useState( false );

    useEffect( () => {
        axios.get( 'http://localhost:8000/api/find' )
            .then( res => {
                setProduct( res.data );
                setLoaded( true );
            } );
    }, [] );
    
    const removeFromDom = productId => {
        setProduct( product.filter( pro => pro._id != productId ) );
    };

    return (
        <div>
            <ProductForm />
            <h1>Product List</h1>
            {loaded && <ProductList product={product} removeFromDom={removeFromDom}/>}
        </div>
    )
}