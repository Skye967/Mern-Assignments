
import './App.css';
import PropUp from './components/PropUp';

function App(){
  return (
    <div>
      <div className="App">
        <h2 className="head"> <PropUp lastName={ "Doe" }/>, <PropUp firstName={ "Jane" }/></h2>
        <p className="head">Age: <PropUp age={ "45" } /></p>
        <p className="head">Hair Color<PropUp hairColor={"Black"}/></p>
      </div>
      <div className="App">
        <h2 className="head"> <PropUp lastName={ "Smith" }/>, <PropUp firstName={ "John" }/></h2>
        <p className="head">Age: <PropUp age={ "88" } /></p>
        <p className="head">Hair Color: <PropUp hairColor={"Brown"}/></p>
      </div>
      <div className="App">
        <h2 className="head"> <PropUp lastName={ "Fillimore" }/>, <PropUp firstName={ "Millard" }/></h2>
        <p className="head">Age: <PropUp age={ "50" } /></p>
        <p className="head">Hair Color: <PropUp hairColor={"Brown"}/></p>
      </div>
      <div className="App">
        <h2 className="head"> <PropUp lastName={ "Smith" }/>, <PropUp firstName={ "Maria" }/></h2>
        <p className="head">Age: <PropUp age={ "62" } /></p>
        <p className="head">Hair Color: <PropUp hairColor={"Brown"}/></p>
      </div>
    </div>
  );
}

export default App;
