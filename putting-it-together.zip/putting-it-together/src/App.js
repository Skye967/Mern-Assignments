
import './App.css';
import BirthdayComponent from './components/BirthdayComponent.js';
function App () {
  

  return (
    <div className="App">
        <BirthdayComponent lastName = {"Doe"} firstName={ "Jane" } age = {45} hairColor={ "Black" }/> 
     
        <BirthdayComponent lastName = {"Smith"} firstName={ "John" } age = {88} hairColor = {"Brown"}/>
    </div>
  );
}

export default App;
