import React, { Component } from "react";
class BirthdayComponent extends Component {
    constructor ( props ) {
        super( props );

        this.state = {
            firstName: this.props.firstName,
            lastName: this.props.lastName,
            age: this.props.age,
            hairColor: this.props.hairColor
        }
        
    }

    happyBirthday = () => {
        console.log( "works" );
        this.setState( {
            age : this.state.age + 1
        })
        }

    render() {
        return (
            <div>
                <h1>{ this.state.lastName }, 
                { this.state.firstName }</h1>
                <p className = "head">Age: { this.state.age }</p>
                <p className = "head">Hair Color: { this.state.hairColor }</p>
                <button type="button" onClick={this.happyBirthday}>Happy Birthday</button>
            </div>
        );
    }
}

export default BirthdayComponent;