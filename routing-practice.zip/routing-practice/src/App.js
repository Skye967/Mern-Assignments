import logo from './logo.svg';
import './App.css';
import { Router } from '@reach/router';
import PageOne from './components/pageOne';
import { Link, navigate } from '@reach/router';

function App() {
  return (
    <div className="App">
      <h1>Routing Practice</h1>
      <Router>
        <PageOne path="/route-one/:someVar/:textColor/:backgroundColor"/>
      </Router>
      <Link to="/route-one">Page One</Link>
    </div>
  );
}

export default App;
