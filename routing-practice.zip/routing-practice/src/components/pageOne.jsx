import React from 'react';
import { Link, navigate } from '@reach/router';

const PageOne = ( props ) => {

    const someVar = props.someVar;
    const textColor = props.textColor;
    const backColor = props.backgroundColor;
    console.log( someVar );

    const thisStyle = {
        color: textColor,
        backgroundColor: backColor 
    };
    
    const Num = isNaN( someVar );
    console.log( Num );

    const onClickHandler = ( event ) => {
        event.preventDefault();
        navigate( '/' );
    };

    return (
      <div>
            <h1>Page one</h1>
            <div style={thisStyle}>
                { Num === false && 
                <p>The number is: { someVar }</p> }
                { Num === true && 
                <p>The word is: {someVar}</p> }
            </div>
            <button onClick={onClickHandler}>Dashboard</button>
      </div>
  );
}

export default PageOne;