import logo from './logo.svg';
import './App.css';
import Tab from './components/Tab';

function App () {
  

  return (
    <div className="App">
      <Tab />
    </div>
  );
}

export default App;
