import React, { Component } from "react";

class Tag extends Component {
    constructor ( props ) {
        super( props );

        this.state = {
            tab: ""
        };
    }

    // happyBirthday = () => {
    //     console.log( "works" );
    //     this.setState( {
    //         age : this.state.age + 1
    //     })
    //     }

    displayChange = (e) => {
        console.log( e.target.className );
        if ( e.target.className === "tab1" ) {
            this.setState( {
            tab : "Displaying content for Tab1"
            })
        }
        if ( e.target.className === "tab2" ) {
            this.setState( {
            tab : "Tab2 content displaying here just fine"
            })
        }
        if ( e.target.className === "tab3" ) {
            this.setState( {
            tab : "Nobody ever remembers 3rd place"
            })
        }
        } 
    
    render(){
        return (
            <div>
                <div className="tab_container">
                    <div className="tab1" onClick={this.displayChange}>Tab 1</div>
                    <div className="tab2" onClick={this.displayChange}>Tab 2</div>
                    <div className="tab3" onClick={this.displayChange}>Tab 3</div>
                </div>
                <div className="content_container">{ this.state.tab }</div>
            </div>
        );
    }
}

export default Tag;