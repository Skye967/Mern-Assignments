import React, { useState } from 'react';
import './App.css';
import ToDoList from './components/todoList.js';

function App () {
  const [ tasks, setTasks ] = useState( [] );
  
  const addNewTask = ( newTask ) => {
    const newTaskArr = [ ...tasks ];
    newTaskArr.push( newTask );
    setTasks( newTaskArr );
  };

  const completeTask = ( i, value ) => {
    let copy = [ ...tasks ];
    copy[ i ].completed = value;
    setTasks(
      copy
    )
  }

  const onDeleteTask = ( i ) => {
    let newTasks = [ ...tasks ];
    newTasks.splice( i, 1 );
     setTasks(
            newTasks
        );
  }

    return (
      <div className="App">
        <ToDoList onDeleteTask={onDeleteTask} addNewTask={ addNewTask } tasks={ tasks } setTasks={setTasks} onCompleteTask={completeTask}/>
      </div>
    );
}

export default App;
