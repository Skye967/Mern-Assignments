import React from "react";
import { useState } from 'react';


const TaskDisplay = ( { tasks } ) => {
    const [ task, setTask ] = useState( {
        content: "",
        completed: "No"
    } );
    
    const completeHandle = (e, update) => {
        setTask( {
            ...update,
            [ e.target.name ]: e.target.value
        } );
        console.log( e.target.name )
        console.log( e.target.value )
        console.log( task );
    }
    
    return (
        <div className="boxes">
                {/* {
                    tasks.map( ( task, i ) => {
                        return (
                            <div className="box" key={ i }>
                                <p>{ task.content } </p>
                                <p>Is Completed: { task.completed }</p>
                                { task.completed === "No" &&
                                    <p>Check if Completed: <input type="checkbox" name="completed" value="Yes" onChange={(e) => completeHandle(e, task) }/></p>
                                    
                                }
                            </div>
                        )
                    })
                } */}
        </div>
    );
};

export default TaskDisplay;
