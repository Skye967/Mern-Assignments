import React, { useState } from 'react';

const ToDoList = ( props ) => {
    const [ task, setTask ] = useState( {
        content: "",
        completed: false
    } );

    const createTask = ( e ) => {
        e.preventDefault();
        props.addNewTask( task );

    };

    const handleBoxColor = ( e ) => {
        setTask( {
            ...task,
            [ e.target.name ]: e.target.value
        } );
    };

    const updateTask = ( i, value ) => {
        props.onCompleteTask( i, value );
        setTask({
            completed: false
        })
    }

    const deleteTask = ( i ) => {
        props.onDeleteTask( i );
    }



    return (
        <div>
        <form onSubmit={createTask}>
            <label>Task: </label>
            <input type="text" name="content" onChange={ handleBoxColor } />
            <input type="submit" />
        </form>
            {
                props.tasks.map( ( task, i ) => {
                    return (
                            <div className="box" key={ i }>
                                <p>{ task.content } </p>
                                <p class="row">Is Completed: { task.completed === false && <p>No</p> } { task.completed === true && <p>Yes</p> }</p>
                                { task.completed === false &&
                                <p>Check if Completed: <input type="checkbox" name={i} value={task.completed} key={ i } onChange={e => updateTask(i,e.target.checked)}/></p>
                            }
                            { task.completed === true &&
                                <p><button name={i} key={ i } onClick={e => deleteTask(i)}>Delete</button></p>
                                }
                            </div>
                        )
                })
            }
        </div>
    );
};


export default ToDoList;